# README #

RemoteDesktop access via WinAPI

### Usage ###

- C#
- WPF (MVVM)

