﻿using System.Windows;

namespace Rdp.Demostration
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}