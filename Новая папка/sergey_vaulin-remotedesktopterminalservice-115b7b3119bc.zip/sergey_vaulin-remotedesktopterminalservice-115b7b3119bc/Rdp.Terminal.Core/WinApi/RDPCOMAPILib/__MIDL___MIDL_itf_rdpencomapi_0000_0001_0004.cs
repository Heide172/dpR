﻿namespace RDPCOMAPILib
{
    public enum __MIDL___MIDL_itf_rdpencomapi_0000_0001_0004
    {
        CHANNEL_FLAGS_LEGACY = 1,

        CHANNEL_FLAGS_UNCOMPRESSED = 2,
    }
}