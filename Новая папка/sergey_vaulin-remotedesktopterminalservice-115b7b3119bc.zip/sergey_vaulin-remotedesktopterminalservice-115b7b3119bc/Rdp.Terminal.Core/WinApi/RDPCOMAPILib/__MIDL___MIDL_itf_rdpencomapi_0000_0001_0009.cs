﻿namespace RDPCOMAPILib
{
    public enum __MIDL___MIDL_itf_rdpencomapi_0000_0001_0009
    {
        APP_FLAG_PRIVILEGED = 1,
    }
}