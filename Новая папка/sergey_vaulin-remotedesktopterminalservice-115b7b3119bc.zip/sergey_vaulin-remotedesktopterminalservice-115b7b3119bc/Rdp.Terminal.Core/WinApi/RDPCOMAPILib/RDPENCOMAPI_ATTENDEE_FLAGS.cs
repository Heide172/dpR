﻿namespace RDPCOMAPILib
{
    public enum RDPENCOMAPI_ATTENDEE_FLAGS
    {
        ATTENDEE_FLAGS_LOCAL = 1,
    }
}