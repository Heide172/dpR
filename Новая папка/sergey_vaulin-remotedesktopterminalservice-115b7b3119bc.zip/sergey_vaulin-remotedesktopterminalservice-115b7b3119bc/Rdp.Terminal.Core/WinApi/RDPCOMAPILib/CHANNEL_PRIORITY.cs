﻿namespace RDPCOMAPILib
{
    public enum CHANNEL_PRIORITY
    {
        CHANNEL_PRIORITY_LO,

        CHANNEL_PRIORITY_MED,

        CHANNEL_PRIORITY_HI,
    }
}