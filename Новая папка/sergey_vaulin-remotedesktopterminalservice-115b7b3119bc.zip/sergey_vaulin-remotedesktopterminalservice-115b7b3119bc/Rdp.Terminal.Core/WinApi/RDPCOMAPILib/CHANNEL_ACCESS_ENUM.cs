﻿namespace RDPCOMAPILib
{
    public enum CHANNEL_ACCESS_ENUM
    {
        CHANNEL_ACCESS_ENUM_NONE,

        CHANNEL_ACCESS_ENUM_SENDRECEIVE,
    }
}