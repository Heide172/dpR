﻿namespace RDPCOMAPILib
{
    public enum RDPSRAPI_APP_FLAGS
    {
        APP_FLAG_PRIVILEGED = 1,
    }
}