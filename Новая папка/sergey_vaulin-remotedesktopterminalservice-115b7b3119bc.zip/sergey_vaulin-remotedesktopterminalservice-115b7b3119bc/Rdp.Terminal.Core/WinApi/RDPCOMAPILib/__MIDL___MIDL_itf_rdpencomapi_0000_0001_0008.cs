﻿namespace RDPCOMAPILib
{
    public enum __MIDL___MIDL_itf_rdpencomapi_0000_0001_0008
    {
        WND_FLAG_PRIVILEGED = 1,
    }
}