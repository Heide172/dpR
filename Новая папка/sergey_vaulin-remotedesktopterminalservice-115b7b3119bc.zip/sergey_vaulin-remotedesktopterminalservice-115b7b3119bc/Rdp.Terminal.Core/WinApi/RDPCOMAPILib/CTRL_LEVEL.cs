﻿namespace RDPCOMAPILib
{
    public enum CTRL_LEVEL
    {
        CTRL_LEVEL_INVALID = 0,

        CTRL_LEVEL_MIN = 0,

        CTRL_LEVEL_NONE = 1,

        CTRL_LEVEL_VIEW = 2,

        CTRL_LEVEL_INTERACTIVE = 3,

        CTRL_LEVEL_MAX = 3,
    }
}