﻿namespace RDPCOMAPILib
{
    public enum CHANNEL_FLAGS
    {
        CHANNEL_FLAGS_LEGACY = 1,

        CHANNEL_FLAGS_UNCOMPRESSED = 2,
    }
}