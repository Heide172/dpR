﻿namespace RDPCOMAPILib
{
    public enum __MIDL___MIDL_itf_rdpencomapi_0000_0001_0003
    {
        CHANNEL_PRIORITY_LO,

        CHANNEL_PRIORITY_MED,

        CHANNEL_PRIORITY_HI,
    }
}