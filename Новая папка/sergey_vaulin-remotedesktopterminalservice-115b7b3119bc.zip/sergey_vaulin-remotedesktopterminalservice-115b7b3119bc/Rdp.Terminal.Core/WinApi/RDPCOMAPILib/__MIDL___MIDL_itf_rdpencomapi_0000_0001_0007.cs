﻿namespace RDPCOMAPILib
{
    public enum __MIDL___MIDL_itf_rdpencomapi_0000_0001_0007
    {
        ATTENDEE_FLAGS_LOCAL = 1,
    }
}