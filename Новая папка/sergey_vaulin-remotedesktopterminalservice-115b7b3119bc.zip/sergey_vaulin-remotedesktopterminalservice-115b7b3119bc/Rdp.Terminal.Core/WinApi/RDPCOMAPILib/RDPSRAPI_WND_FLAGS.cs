﻿namespace RDPCOMAPILib
{
    public enum RDPSRAPI_WND_FLAGS
    {
        WND_FLAG_PRIVILEGED = 1,
    }
}