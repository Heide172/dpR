namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnAttendeeUpdateEvent
    {
        public object pAttendee;

        public _IRDPSessionEvents_OnAttendeeUpdateEvent(object pAttendee)
        {
            this.pAttendee = pAttendee;
        }
    }
}