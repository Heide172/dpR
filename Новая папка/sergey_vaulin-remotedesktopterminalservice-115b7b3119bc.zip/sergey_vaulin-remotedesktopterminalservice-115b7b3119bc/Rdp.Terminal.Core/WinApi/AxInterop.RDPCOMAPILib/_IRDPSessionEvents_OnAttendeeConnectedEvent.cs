namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnAttendeeConnectedEvent
    {
        public object pAttendee;

        public _IRDPSessionEvents_OnAttendeeConnectedEvent(object pAttendee)
        {
            this.pAttendee = pAttendee;
        }
    }
}