namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnWindowOpenEvent
    {
        public object pWindow;

        public _IRDPSessionEvents_OnWindowOpenEvent(object pWindow)
        {
            this.pWindow = pWindow;
        }
    }
}