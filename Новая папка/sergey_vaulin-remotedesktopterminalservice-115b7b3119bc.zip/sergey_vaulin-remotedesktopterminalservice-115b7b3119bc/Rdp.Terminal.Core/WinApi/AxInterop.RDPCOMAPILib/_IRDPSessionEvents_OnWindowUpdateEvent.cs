namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnWindowUpdateEvent
    {
        public object pWindow;

        public _IRDPSessionEvents_OnWindowUpdateEvent(object pWindow)
        {
            this.pWindow = pWindow;
        }
    }
}