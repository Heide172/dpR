namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnErrorEvent
    {
        public object errorInfo;

        public _IRDPSessionEvents_OnErrorEvent(object errorInfo)
        {
            this.errorInfo = errorInfo;
        }
    }
}