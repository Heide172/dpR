namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnApplicationCloseEvent
    {
        public object pApplication;

        public _IRDPSessionEvents_OnApplicationCloseEvent(object pApplication)
        {
            this.pApplication = pApplication;
        }
    }
}