namespace AxRDPCOMAPILib
{
    internal class _IRDPSessionEvents_OnApplicationOpenEvent
    {
        public object pApplication;

        public _IRDPSessionEvents_OnApplicationOpenEvent(object pApplication)
        {
            this.pApplication = pApplication;
        }
    }
}